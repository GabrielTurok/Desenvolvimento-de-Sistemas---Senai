package com.example.demo.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.demo.Model.LivroModel;
import com.example.demo.Repository.LivroRepository;

@SpringBootApplication
public class LivroService {


    @Autowired
    private LivroRepository repository;

    public List<LivroModel> listarTodos(){
        return repository.findAll();
    }

    public Optional<LivroModel> buscarPorId(long id){
        return repository.findById(id);

    }

    public LivroModel criar(LivroModel livroModel){
        return repository.save(livroModel);
    }
    
    public LivroModel ediçao(long id, LivroModel livroModel){
        return repository.save(livroModel);
    }
    

    public void deletar(long id){
        repository.deleteById(id);


}
}