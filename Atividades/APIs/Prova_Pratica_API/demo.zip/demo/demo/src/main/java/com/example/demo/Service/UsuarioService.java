package com.example.demo.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.demo.Model.UsuarioModel;
import com.example.demo.Repository.UsuarioRepository;

@SpringBootApplication
public class UsuarioService {


    @Autowired
    private UsuarioRepository repository;

    public List<UsuarioModel> listarTodos(){
        return repository.findAll();
    }

    public Optional<UsuarioModel> buscarPorId(long id){
        return repository.findById(id);

    }

    public UsuarioModel criar(UsuarioModel usuarioModel){
        return repository.save(usuarioModel);
    }
    
    public UsuarioModel atualizar(long id, UsuarioModel usuarioModel){
        return repository.save(usuarioModel);
    }
    

    public void deletar(long id){
        repository.deleteById(id);


}
}